/*Em uma loja de eletrodom�sticos, os funcion�rios da se��o de TVs recebem,
mensalmente um sal�rio fixo mais comiss�o. Essa comiss�o � calculada em rela��o
ao tipo e n�mero de televisores vendidos, de acordo com a tabela abaixo:
Tipo                    Quantidade vendida                    Comiss�es
  8K                        10 ou mais                  R$ 25 por TV vendida
						   menos que 10                 R$ 10 por TV vendida
  4K                        10 ou mais                  R$ 15 por TV vendida
						   menos que 10                 R$ 5 por TV vendida
Sabe-se ainda, que ele tem um desconto de 8% do sal�rio total para pagamento do
INSS e se o seu sal�rio for superior � R$950,00 ele ainda tem um desconto de 5% do
sal�rio para fins de imposto de renda. Fa�a um programa que leia os dados de v�rios
funcion�rios e:
a. Para cada funcion�rio, calcule o sal�rio l�quido (j� com os descontos).
b. Imprima o n�mero de funcion�rios.
c. Imprima o total de sal�rios pagos.
d. Imprima o m�dia das comiss�es.
e. Imprima o valor da maior e menor comiss�o paga pelo departamento. */
//Realizada por: Bruna Andrade;

#pragma warning (disable: 4996)
#include <stdio.h>
#include <stdlib.h>
#define COMISSAO_TV_8K_10_OU_MAIS_VENDIDAS 25
#define COMISSAO_TV_8K_MENOS_DE_10_VENDIDAS 10
#define COMISSAO_TV_4K_10_OU_MAIS_VENDIDAS 15
#define COMISSAO_TV_4K_MENOS_DE_10_VENDIDAS 5
#define DESCONTO_INSS 0.08
#define IMPOSTO_RENDA 0.05 

main() {
	int funcionarios, i, quantidade_tv_8k, quantidade_tv_4k, comissao_8k, comissao_4k, comissao_total, total_comissoes = 0;
	float menor_comissao = 0, maior_comissao = 0;
	float salario, salario_total, salario_liquido, total_salarios = 0;

	do {
		printf("Digite quantos funcionarios gostaria de cadastrar: ");
		scanf("%d", &funcionarios);
		if (funcionarios <= 0)
			printf("Valor invalido!");
	} while (funcionarios <= 0);

	for (i = 1; i <= funcionarios; i++)
	{
		system("cls");
		do {
			printf("\nDigite qual o salario do funcionario %d: ", i);
			scanf("%f", &salario);
			if (salario <= 0)
				printf("Valor invalido!");
		} while (salario <= 0);

		do {
			printf("\nQuantas televisoes 8k foram vendidas por esse funcionario?  ");
			scanf("%d", &quantidade_tv_8k);
			if (quantidade_tv_8k < 0)
				printf("Valor invalido!");
		} while (quantidade_tv_8k < 0);

		if (quantidade_tv_8k >= 10) 
			comissao_8k = quantidade_tv_8k * COMISSAO_TV_8K_10_OU_MAIS_VENDIDAS;
		else 
			comissao_8k = quantidade_tv_8k * COMISSAO_TV_8K_MENOS_DE_10_VENDIDAS;
		
		do {
			printf("\nQuantas televisoes 4k foram vendidas por esse funcionario?  ");
			scanf("%d", &quantidade_tv_4k);
			if (quantidade_tv_4k < 0)
				printf("Valor invalido!");
		} while (quantidade_tv_4k < 0);

		if (quantidade_tv_4k >= 10)
			comissao_4k = quantidade_tv_4k * COMISSAO_TV_4K_10_OU_MAIS_VENDIDAS;
		else
			comissao_4k = quantidade_tv_4k * COMISSAO_TV_4K_MENOS_DE_10_VENDIDAS;

		comissao_total = comissao_4k + comissao_8k;

		if (maior_comissao == 0)
			maior_comissao = comissao_total;
		if (menor_comissao == 0)
			menor_comissao = comissao_total;
		
		if (comissao_total > maior_comissao)
			maior_comissao = comissao_total;

		if (comissao_total < menor_comissao)
			menor_comissao = comissao_total;

		salario_total = salario + comissao_4k + comissao_8k;

		total_comissoes += comissao_total;
		total_salarios += salario_total;

		if (salario <= 950)
			salario_liquido = salario_total - (salario_total * DESCONTO_INSS);
		else 
			salario_liquido = salario_total - (salario_total * DESCONTO_INSS) - (salario_total * IMPOSTO_RENDA);

		printf("++++    O salario do funcionario %d eh: %.2f    ++++", i, salario_liquido);
		getche();
	}
	system("cls");
	printf("\n O numero de Funcionarios cadastrado foi: %d\n", funcionarios);
	printf("\n O salario total dos funcionarios foi de:R$ %.2f\n", total_salarios);
	printf("\n A media de comissoes fo dei: R$ %.2f\n", (float)(total_comissoes / funcionarios) );
	printf("\n A menor comissao foi de:R$ %.2f\n ", menor_comissao);
	printf("\n A maior comissao foi de:R$ %.2f\n\n", maior_comissao);
	system("pause");
	return 0;
}
//Revisada por: Ana Clara e Bruna Andrade;